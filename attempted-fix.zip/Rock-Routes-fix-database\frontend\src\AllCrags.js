import { useEffect, useState } from "react";
import { apiFetch } from "./api";

function AllCrags() {
  const [crags, setCrags] = useState([]);

  useEffect(() => {
    apiFetch("/api/crags").then((data) => setCrags(data));
  }, []);

  return (
    <div>
      <h1>All Crags</h1>

      {crags.map((crag, index) => (
        <div key={index}>
          <h3>{crag.route_name}</h3>
        </div>
      ))}
    </div>
  );
}

export default AllCrags;
