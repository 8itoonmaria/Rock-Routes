const API_BASE = process.env.REACT_APP_API_BASE || "";

export async function apiFetch(path, options = {}) {
  const response = await fetch(`${API_BASE}${path}`, options);
  const contentType = response.headers.get("content-type") || "";
  const isJson = contentType.includes("application/json");
  const body = isJson ? await response.json() : await response.text();

  if (!response.ok) {
    const message =
      (isJson && body && body.message) || `${response.status} ${response.statusText}`;
    const detail = !isJson && body ? ` (received HTML instead of JSON)` : "";
    const error = new Error(message + detail);
    error.status = response.status;
    error.body = body;
    throw error;
  }

  return body;
}
